CREATE VIEW tmp_year_table AS
  SELECT date_format(curdate(), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 1 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 2 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 3 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 4 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 5 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 6 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 7 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 8 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 9 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 10 MONTH), '%Y年%m月') AS `month`
  UNION SELECT date_format((curdate() - INTERVAL 11 MONTH), '%Y年%m月') AS `month`;
